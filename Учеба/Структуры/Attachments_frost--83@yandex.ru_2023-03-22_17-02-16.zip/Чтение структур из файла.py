print('Чтение структур из файла')

import pickle

Fin = open('E:\List_of_dogs.dat','rb')

a = pickle.load(Fin)
print(a[i].name,a[i].breed,a[i].age)
Fin.close()