print('Действия с элементами файла - поиск Мах и Min значения') 
from random import*

Fout = open('G:\File_rand_el.txt','w')
Fin = open('G:\File_rand_el.txt','r')


A = [randint(-100,100) for i in range(50)]
print(A)  

Fout.write(str(A))

#Нужно прочитать файл и далее работать с полученными значениями





List_pol = []
for x in A:
    if x > 0 and x % 2 == 0:
        List_pol.append(x)

print('Четные положительные числа')        
print(List_pol)        
print()

Max = A[0] 

for x in List_pol: 
    if x > Max:
        Max = x
print(x)        
       
Min = A[0] 

for y in List_pol: 
    if y <  Min:
        Min = y
        
        







